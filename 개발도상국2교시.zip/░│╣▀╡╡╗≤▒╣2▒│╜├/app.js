const express = require('express'); // express라는 도구(서버에 필요한 것들)를 사용해서 express라는 변수에 저장.
const helmet = require("helmet");
const app = express();
const ejs = require("ejs")
const db = require('./model/db')


// 그림파일 띄우려면 밑에 3줄이 필요하다.
app.set('view engine', 'ejs'); //view 파일을 보여주는 엔진 : ejs 확장자를 그림파일로
app.set('views', './views') //내가만든 html파일들은 ./views 폴더에 있다.
app.use('/public', express.static(__dirname+'/public')); //express 도움을 받아 css나 이미지 파일은 /public 파일에 있다.

app.use(helmet()); //미들웨어 역할을 해주는 거
// post에서 body에서 서버에서 가져올 수 있도록 해줌
app.use(express.json());
app.use(express.urlencoded());


//사이트 -> 요청 ->(MiddleWare())----> Node.js

const mainRouter = require('./router/mainRouter') // './'는 같은 경로의 폴더. 주소경로를 사용해줘서 mainRouter로 변수 설정
app.use('/', mainRouter) //미들웨어에 설정. '/'를 디폴드 기준으로 주소를 설정해준다. 나중에 여러 경로를 설정해줄 수 있다.


app.listen(3000, function(req,res){ //3000 번 포트를 사용해서 서버를 실행할거다.
    db.sequelize.sync({force:false})
    console.log("서버가 실행되고 있다!")
})

