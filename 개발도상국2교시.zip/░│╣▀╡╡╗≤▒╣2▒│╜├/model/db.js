var Sequelize = require("sequelize");
var sequelize;

sequelize = new Sequelize("class101","root","1234",{
    host:"localhost",
    port:3306,
    dialect:"mysql",
    timezone:"+09:00",
    define:{
        charset:"utf8",
        collate:"utf8_general_ci",
        timestamps:true, //데이터가 생성된 시간을 표시
        freezeTableName:true
    }
})

var db = {};
db.users = sequelize.import(__dirname + "/users.js");

db.sequelize = sequelize;
db.Sequelize = Sequelize;

module.exports = db;