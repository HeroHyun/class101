# 개발자 사관학교 2교시

# mdn node js
1) 이걸로 공식문서 확인해보기

# 시작하기
1) npm install express 로 설치하면 node_modules 폴더가 생성됨
2) package.json에 dependencies에서 express 버전 확인 가능하다.
3) npm install supervisor -g 을하고나면 이제 변경있을 시 알아서 서버를 껏다가 켜줘서 적용시켜줌.

4) 번외로 npm helmet은 보안 관련 설정을 해주는 라이브러리